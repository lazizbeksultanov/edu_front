export const config = {
    BASE_URL: 'http://localhost/api',
    // BASE_URL: 'http://localhost:9000/api',
};
